import programa_1,programa_2,programa_3,programa_4,programa_5,programa_6,programa_7,programa_8,programa_9,programa_10
import programa_11,programa_12,programa_13,programa_14,programa_15,programa_16,programa_17,programa_18,programa_19,programa_20
import programa_21,programa_22,programa_23,programa_24,programa_25,programa_26,programa_27,programa_28,programa_29,programa_30
import programa_31,programa_32,programa_33,programa_34,programa_35,programa_36,programa_37,programa_38,programa_39,programa_40
import programa_41,programa_42,programa_43,programa_44,programa_45,programa_46,programa_47,programa_48,programa_49,programa_50
def menu_portafolio():
    while True:
        print("\n \n 🛠😄==== Menú ====😄🛠")
        print("1-10. ingrese un numero del 1 al 10 para los programas de flujo ")
        print("11-30. ingrese un numero entre 11 al 30 para programas de secuencia if ")
        print("31-40. ingrese un numero entre 31 al 40 para ejecutar un programa de bucle while")
        print("41-50: ingrese un numero entre 41 al 50 para ejecutar un programa de bucle for")
        print("q. Salir")
        choice = input("Elige un numero del programa que quiere ejecutar: ")
        print("\n")

        match choice:
            case "1":
                programa_1.prog_1()
            case "2":
                programa_2.prog_2()
            case "3":
                programa_3.prog_3()
            case "4":
                programa_4.prog_4()
            case "5":
                programa_5.prog_5()
            case "6":
                programa_6.prog_6()
            case "7":
                programa_7.prog_7()
            case "8":
                programa_8.prog_8()
            case "9":
                programa_9.prog_9()
            case "10":
                programa_10.prog_10()
            case "11":
                programa_11.prog_11()
            case "12":
                programa_12.prog_12()
            case "13":
                programa_13.prog_13()
            case "14":
                programa_14.prog_14()
            case "15":
                programa_15.prog_15()
            case "16":
                programa_16.prog_16()
            case "17":
                programa_17.prog_17()
            case "18":
                 programa_18.prog_18()
            case "19":
                 programa_19.prog_19()
            case "20":
                 programa_20.prog_20()
            case "21":
                 programa_21.prog_21()
            case "22":
                 programa_22.prog_22()
            case "23":
                 programa_23.prog_23()
            case "24":
                 programa_24.prog_24()
            case "25":
                 programa_25.prog_25()
            case "26":
                 programa_26.prog_26()
            case "27":
                 programa_27.prog_27()
            case "28":
                 programa_28.prog_28()
            case "29":
                 programa_29.prog_29()
            case "30":
                 programa_30.prog_30()
            case "31":
                 programa_31.prog_31()
            case "32":
                 programa_32.prog_32()
            case "33":
                 programa_33.prog_33()
            case "34":
                 programa_34.prog_34()
            case "35":
                 programa_35.prog_35()
            case "36":
                 programa_36.prog_36()
            case "37":
                 programa_37.prog_37()
            case "38":
                 programa_38.prog_38()
            case "39":
                programa_39.prog_39()
            case "40":
                 programa_40.prog_40()
            case "41":
                 programa_41.prog_41()
            case "42":
                 programa_42.prog_42()
            case "43":
                 programa_43.prog_43()
            case "44":
                 programa_44.prog_44()
            case "45":
                 programa_45.prog_45()
            case "46":
                 programa_46.prog_46()
            case "47":
                 programa_47.prog_47()
            case "48":
                 programa_48.prog_48()
            case "49":
                 programa_49.prog_49()
            case "50":
                 programa_50.prog_50()
            case "q":
                print("Saliendo...")
                break
            case _:
                print("Opción no válida, intenta de nuevo.")
                

if __name__ == "__main__":
    menu_portafolio()
