def prog_1():
    print("ALGORITMO QUE SUME DOS VALORES")
    print("|---------------------------------|")
    
    A=float(input("ingrese el primer valor : "))
    B=float(input("ingrese el segundo valor : "))
    
    print("|_____________________________|")
    print(" la cantidad total es : ", end='')
    C=print(A+B)
