def prog_11():
    print("🛠🛠️PROGRAMA QUE INDICA SI EL NUMERO INGRESADO ES POSITIVO O NEGATIVO Y CERO  🛠🛠 ")
    print("======================================================================================")
    numero= int(input(" escribe el numero : "))
    print("||====================||")
    if numero >0:
        print(f" el numero {numero} es positivo")
        
    elif numero ==0:
        print(f" el numero {numero} es cero ")
        
    else:
        print(f" el numero {numero} es negativo ")
