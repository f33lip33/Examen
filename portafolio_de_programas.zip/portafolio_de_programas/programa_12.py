def prog_12():
    # 2 Escribe un programa que solicite la edad del usuario y determine si es un adolescente
    #(entre 13 y 19 años).

    print("programa que solicite la edad del usuario y determine si es un adolescente")
    print("===========================================================================")
    edad = int(input("Ingrese la edad : "))

    if edad >= 13 and edad <= 19:
     print("es adolencente")
      
    else:
      print("no eres adolecente ")
