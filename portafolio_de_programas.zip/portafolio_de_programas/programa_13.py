def prog_13():
    # 3 Escribe un programa que solicite al usuario un número y determine si es múltiplo de 5.
    print(" programa de multiplos de 5")
    print("==============================")
    numero = int(input(" escriba el numero : "))

    if numero % 5 == 0:
        
      print(numero, "es múltiplo de 5.")
      
    else:
      print(numero, "no es múltiplo de 5.")
