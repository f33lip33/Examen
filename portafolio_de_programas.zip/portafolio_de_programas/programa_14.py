def prog_14():
    print("programa que diga si es una vocal o no ")
    print("|======================================|")
    letra_usuario = input("Ingrese una letra: ")
    print("|----------------------|")
    # Convertimos la letra a minúscula para simplificar la comparación
    letra_usuario = letra_usuario.lower()

    # Verificamos si la letra ingresada es una vocal
    if letra_usuario == 'a' or letra_usuario == 'e' or letra_usuario == 'i' or letra_usuario == 'o' or letra_usuario == 'u':
        print(f"= La letra '{letra_usuario}' es una vocal.")
    else:
        print(f"La letra '{letra_usuario}' no es una vocal.")

