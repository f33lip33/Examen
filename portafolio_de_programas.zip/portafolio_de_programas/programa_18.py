def prog_18():

    print("programa que solicite un número y determine si está entre 1 y 100")
    print("==================================================================")
    numero=float(input("Ingrese el numero : "))

    if numero >= 1 and numero <= 100:
      print("si esta entre los valores 1 y 100")
    else :
        print("el numero no esta entre los valores 1 y 100")
      
