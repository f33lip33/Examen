def prog_2():
    
    print("CALCUALAR IMPUESTO")
    print("|==================|")
    precio=float(input("ingrese el precio del producto : "))
    cantidad=float(input("ingrese la cantidad del producto : "))
    impuestos=float(input("ingrese la cantidad del impuesto : "))
    print("|-----------------------------|")
    print("impuesto del producto : ", end='')
    p1=( precio * cantidad )
    p2=( p1 * 0.10 )
    p3=print( p1 + p2 )
