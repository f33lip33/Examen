def prog_24():
    print("📐📐 DETERMINAR SI LOS LADOS FORMAN UN TRIÁNGULO O NO 📐📐")
    print("===========================================================")

    # Solicitar las longitudes de los lados al usuario
    lado1 = float(input("Ingrese la longitud del primer lado del triángulo: "))
    lado2 = float(input("Ingrese la longitud del segundo lado del triángulo: "))
    lado3 = float(input("Ingrese la longitud del tercer lado del triángulo: "))
    print("____________________________________________________")

    # Verificar si los lados ingresados pueden formar un triángulo
    if lado1 + lado2 > lado3 and lado1 + lado3 > lado2 and lado2 + lado3 > lado1:
        print("Los lados ingresados forman un triángulo válido.")
    else:
        print("Los lados ingresados no forman un triángulo válido.")
