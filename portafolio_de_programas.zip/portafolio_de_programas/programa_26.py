def prog_26():
    print("🛠🛠️ CLASIFICACION DE MASA CORPORAL (IMC) 🛠🛠")
    print("==================================================")

    # Solicitar peso y altura al usuario
    peso = float(input("Ingrese su peso en kg: "))
    altura = float(input("Ingrese su altura en metros: "))
    print("________________________________________________________")

    # Calcular el IMC
    imc = peso / (altura ** 2)

    # Determinar la clasificación según el IMC
    if imc < 18.5:
        clasificacion = "Bajo peso"
    elif imc < 25:
        clasificacion = "Peso normal"
    elif imc < 30:
        clasificacion = "Sobrepeso"
    else:
        clasificacion = "Obesidad"

    # Mostrar el IMC y la clasificación
    print(f"Su Índice de Masa Corporal (IMC) es: {imc:.2f}")
    print(f"Usted tiene: {clasificacion}")
