def prog_28():
    # Título del programa
    print("🛠🛠️ Determinar si un número es divisible entre 3 y 5 🛠🛠")
    print("==============================================================")

    # Solicitamos un número al usuario
    numero = int(input("Introduce un número entero: "))
    print("______________________________________")
    # Verificamos la divisibilidad y mostramos el resultado
    divisible_por_3 = (numero % 3 == 0)
    divisible_por_5 = (numero % 5 == 0)

    if divisible_por_3 and divisible_por_5:
        print(f"{numero} es divisible por 3 y por 5.")
    elif divisible_por_3:
        print(f"{numero} es divisible por 3 pero no por 5.")
    elif divisible_por_5:
        print(f"{numero} es divisible por 5 pero no por 3.")
    else:
        print(f"{numero} no es divisible ni por 3 ni por 5.")

