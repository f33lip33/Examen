def prog_3():
    puntaje = float(input("escriba la nota :"))
    if puntaje >= 91 and puntaje <= 100:
        print("A")
    if puntaje >= 81 and puntaje <= 90:
        print("B")
    if puntaje >= 71 and puntaje <= 80:
        print("C")
    if puntaje >= 61 and puntaje <= 70:
        print("D")
    if puntaje >= 51 and puntaje <= 60:
        print("F")
            
