def prog_30():

    print("🚕🚕 calcular la tarifa de un taxi , si es 2.50 por 1° 10km y 2,50 por km adicional 🚕🚕 ")
    print("=========================================================================================")


    distancia_km = float(input("Ingrese la distancia recorrida en kilómetros: "))
    print("_________________________________________________________")
    # Definir las tarifas por kilómetro
    tarifa_base = 2.50  # Tarifa por kilómetro para los primeros 10 kilómetros
    tarifa_adicional = 2.00  # Tarifa por kilómetro adicional

    # Calcular la tarifa del taxi
    if distancia_km <= 10:
        tarifa_total = distancia_km * tarifa_base
    else:
        tarifa_total = 10 * tarifa_base + (distancia_km - 10) * tarifa_adicional

    # Mostrar la tarifa calculada al usuario
    print(f"La tarifa del taxi para {distancia_km} kilómetros es: ${tarifa_total:.2f}")
