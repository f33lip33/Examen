def prog_31():
    print("programa que sume todos los números del 1 al 100")
    print("================================================")
    i=1

    while(i <= 100):
        print(i)
        i=i+1
        
    print("fin del bucle")
