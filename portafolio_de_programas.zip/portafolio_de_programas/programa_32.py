def prog_32():
    print("📝📝 PROGRAMA QUE CUENTE UN NUMERO 📝📝")
    print("=======================================")
    N=int(input("Ingrese el numero : "))
    contador=1
        
    while N <= 0:
        print("______________________________")
        print(f"El numero {N} no es positivo")
        N=int(input("ingrese un numero que si sea positivo : "))
        
    while contador <= N:
        print(contador)
        contador= contador + 1
        
    print("fin ")
