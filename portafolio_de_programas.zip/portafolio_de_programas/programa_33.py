def prog_33():
    print("📝📝 suma de numeros hasta el hasta el 100 📝📝")
    print("================================================")

    limite = 100
    suma = 0

    while suma < limite:
        numero = int(input("Ingrese un número entero positivo: "))
        if numero <= 0:
            print("El número ingresado no es positivo. Inténtelo de nuevo.")
            continue
        suma += numero
        if suma < limite:
            print(f"Suma parcial: {suma}")
    print("_____________________________________________")
    print(f"\nSe alcanzó o superó el límite de {limite}.")
    print(f"La suma total es: {suma}")
