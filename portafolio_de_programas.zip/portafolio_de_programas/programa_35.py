def prog_35():
    print("😂😂  JUEGO DE ADIVINA EL NUMERO  😂😂 ")
    print("========================================")
    import random
    random_N = random.randint(1, 10)

    print("Adivina el número entre 1 y 10")

    numero= int(input("Ingresa tu numero: "))

    while numero != random_N:
        
        if numero < random_N:
            print("¡El número es mayor!")
            
        else:  
            print("¡El número es menor!")
        
        numero= int(input("Inténtalo de nuevo: "))

    print(f"¡Felicidades! Adivinaste el número {random_N} 😂😂.")
