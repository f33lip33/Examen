def prog_36():
    print("✖️✖️ PROGRAMA QUE MUESTRE LA TABLA DE MULTIPLICAR DE UN NUMERO ✖️✖️")
    print("|====================================================================|")

    numero=int(input("Ingrese un numero : "))
    inicio= 1
     
    while inicio <= 10:
        R= numero * inicio
        print(f"{numero}X{inicio}={R}")
        inicio += 1
    print(" fin del programa")
