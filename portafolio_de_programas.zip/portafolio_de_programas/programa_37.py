def prog_37():
    print("➖ PROGRAMA QUE PIDA UN NUMERO POSITIVO ➕")
    print("|====================================|")

    numero=int(input("Ingrese un numero positivo = "))

    while numero < 0:
        print("!error¡ el numero que ingreso no es positivo ")
        numero=int(input("Ingrese un numero positivo porfavor = "))
        
        if numero > 0:
            print(f"!por fin ¡ el numero {numero} si es positivo ➕")

