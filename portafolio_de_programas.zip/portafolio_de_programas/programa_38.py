def prog_38():
    print("🗳🗳️CANTADOR DE DIGITOS DE UN NUMERO ENTERO  🗳🗳")
    print("|===================================================|")
    n=int(input("Ingrese un numero entero : "))
    c= 0
        
    while n > 0:
        c=c + 1
        n= n //10
          
    print(f"el numero tiene {c} digitos ")
