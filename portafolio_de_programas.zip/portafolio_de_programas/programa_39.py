def prog_39():
    print("🗳️CONVERTIDOR DE NUMERO A NUMERO BINARIO  🗳")
    print("|==============================================|")
    entero = int(input("Ingrese un número entero positivo: "))

    while entero < 0:
        print("!error¡ el numero que ingreso no es positivo ")
        entero=int(input("Ingrese un numero positivo porfavor : "))
    else:
        binario = ''

        while entero > 0:
            residuo = entero % 2
            binario = str(residuo) + binario
            entero //= 2
        
        print(f"El número en binario es: {binario}")
