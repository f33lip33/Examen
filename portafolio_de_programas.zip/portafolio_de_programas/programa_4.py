def prog_4():
    
    print("suma de perimetros de un rectangulo")
    print("|===================================|")

    A=float(input("ingrese el primer lado : "))
    B=float(input("ingrese el segundo lado : "))
    C=float(input("ingrese el tercer lado : "))
    D=float(input("ingrese el cuarto lado :"))

    print("__________________________________")

    print("perimetro del rectangulo es : ", end='')
    P= print( A + B + C + D )
