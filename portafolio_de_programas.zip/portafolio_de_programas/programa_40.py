def prog_40():
    print("🔒🔒 SIMULADOR DE CAJERO AUTOMATICO; TU PIN ES 1414 🔒🔒")
    print("*********************************************************")
    print("*********************************************************")
    pin=(1414)
    intentos = 3 # Número máximo de intentos permitidos
    contador = 1

    c=int(input("🔑 Ingrese su pin: "))
    print()
    print("*******escanendo******")
    while c != pin:
      if contador < intentos:
        print("la contraseña es incorrecta")
        print()
        c=int(input("Ingrese nuevamente su contraseña: "))
        contador += 1
        
      else:
            print("Ha excedido el número máximo de intentos y se ha !bloqueado¡.")
            break

    if c == pin:
        print(" 🔓🔓 la contraseña que ingresaste es correcta 🔓🔓")
