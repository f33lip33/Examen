def prog_41():
    print("✖️ TABLA DE MULTIPLICAR DE UN NUMERO ✖️")
    print("========================================")

    N=int(input("Ingrese un numero entero : "))

    print("______________________________")

    for i in range(1,10+1):
        R= i * N
        print(N,"X",i, "=",R)
        
    print(f"fin de la tabla de multiplicar del {N}")
