def prog_43():
    print("CONTADOR DE VOCALES ")
    print("====================")
    texto=input("Ingrese una cadena de texto : ")
    print("________________________________")

    vocales='a','e','i','o','u','A','E','I','O','U'

    c= 0

    for i in texto:
       if i in vocales :
           c = c + 1
           
    print(f"en texto , {texto} , hay un total de {c} vocales")
        
        
       
