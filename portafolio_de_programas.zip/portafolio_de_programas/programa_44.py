def prog_44():
    print("Imprime todos los números del 10 al 1 en orden descendente usando un ciclo for")
    print("===============================================================================")
    for i in range(10,0,-1):
        print(i)
    print("___")   
    print("FIN")
        
