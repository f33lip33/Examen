def prog_45():
    print("PROGRAMA QUE CALCULE NUMEROS IMAPARES HASTA EL 1")
    print("------------------------------------------------")
    n=int(input("Ingrese un numero positivo : "))
    print("______________________________")
    c= 0

    for i in range(1,n):
        if i % 2 == 1:
            print(i)
            c= c + 1
    print("________________________________________________")        
    print(f"el numero de impares que hay entre {1} y {n} es de {c}")
