def prog_46():
    print("SUMA DE NUMEROS ENTEROS NATURALES")
    print("==================================")
    n=int(input("Ingrese un numero entero positivo : "))
    print("_________________________________________")
    suma= 0

    for x in str(n):
        suma += int(x)
        
    print(f"= La suma de {n} es = {suma}")
