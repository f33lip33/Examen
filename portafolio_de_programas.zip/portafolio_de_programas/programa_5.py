def prog_5():
    print("CALCULAR EL AREA DE UN TRAPESIO")
    print("|================================|")

    base1=float(input("ingrese la longitud de la base mayor : "))
    base2=float(input("ingrese la longitud de la base menor : "))
    altura=float(input("ingrese la altura del trapesio : "))

    print("_____________________________")

    print( "area del trapecio : ", end='')
    area= print((( base1 + base2 ) * altura)/2)

