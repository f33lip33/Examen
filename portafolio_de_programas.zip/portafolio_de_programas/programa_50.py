def prog_50():
    print("REPETIDOR DE CADENA DE TEXTO")
    print("*****************************")
    texto=input("Ingrese una cadena de  texto : ")
    n=int(input("Ingrese el numero de repeticiones : "))

    for i in range(1,n+1):
        print(texto, i)
    print("------")
    print("|Final|")
