def prog_6():
    
    print(" CALCULAR VOLUMEN DE UN PRISMA")
    print("|===============================|")

    L=float(input("ingrese el largo de el prisma : "))
    A=float(input("ingrese el ancho de el prisma : "))
    a=float(input("ingrese el area de el prisma : "))

    print("____________________________")

    print("volumen del prisma = ", end='')
    V= print( L * A * a )
