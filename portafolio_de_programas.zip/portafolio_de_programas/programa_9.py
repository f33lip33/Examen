def prog_9():
    print(" CALCULAR LA FORMULAS")
    print("||=====================||")
    #variable de entrada
    a=float(input(" ingrese el valor a : "))
    b=float(input(" ingrese el valor b : "))
    c=float(input(" ingrese el valor c : "))

    #variable de salida c1,c2,c3,c4,c5,c6

    #INICIO
    #Leer a,b.c
    c1= ( 4 * a ) + ( 3 * b )
    c2=( 21 * a) - 18 + ( 8 * b ) - 5
    c3=( 4 * a ) + ( 3 * b ) + 7
    c5=( 2 * a ) + ( 3 * b ) - ( c**5)
    c6=( 2 * a ) + ( 3 * b ) - ( c**2 )
    #IMPRIMIR
    print(" resultado de c1 : ", c1)
    print(" resultado de c2 : ", c2)
    print(" resultado de c3 : ", c3)
    print(" resultado de c5 : ", c5)
    print(" resultado de c6 : ", c6)

    #FIN
